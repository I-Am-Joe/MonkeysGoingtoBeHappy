var PLAY=1;
var END= 0;

var gameState=PLAY;

var score;


var Banana,BananaImg
var Monkey, MonkeyImg
var obstacleImg, obstacle
var BackgroundImg,backgrounds, goundInvisiable
var StoneImg,Stone

var BananaGroup, StoneGroup

function preload(){
  MonkeyImg = loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png");
  BananaImg = loadImage("banana.png");
  
  BackgroundImg=loadImage("jungle.jpg");
    stoneImg = loadImage("stone.png");

}
function setup() {
  createCanvas(400, 400);
  backgrounds = createSprite(200,380,400,400);
  backgrounds.addAnimations("jungle",BackgroundImg);
  backgrounds.x = backgrounds.width /2;
  backgrounds.velocityX = -(6+3*score/100);
  
  groundInvisiable = (200,380,400,30);
  groundInvisiable.visible = false;
  
  Monkey = createSprite(40,390,10,10);
  Monkey.addAnimations("Monkey",MonkeyImg);
  Monkey.scale = 0.1;
  }

function draw() {
  background(255);
  
  text("Score: "+ score, 500,50);
  
  if(gameState === PLAY){
    if(keyDown("space")){
      Monkey.velocityY = -10;
    }
    Monkey.velocityY = 0.8;
    
    if(backgrounds.x<0){
    backgrounds.x = backgrounds.width/2;
  }
    if(Monkey.isTouching(BananaGroup)){
      score = score + 1;
    }
    switch(score){
      case 10: Monkey.scale=0.12;
        break;
      case 20:Monkey.scale=0.14;
        break;
        case 30: Monkey.scale=0.16;
        break;
        case 40: Monkey.scale=0.18;
        break;
    }
    
    BananaGroup();
    StoneGroup();
    
    if(StoneGroup.isTouching(Monkey)){
      gameState = END;
    }
  }
  
  else if (gameState===END){
    ground.velocityX=0;
    Monkey.velocityY =0;
    BananaGroup.setVelocityXEach(0);
    StoneGroup.setVelocityXEach(0);
    BananaGroup.setLifetimeEach(-1);
    StoneGroup.setVelocityEach(-1);
  }
  
  Monkey.collide(goundInvisiable);
  
  
  drawSprite();
}

function banana(){
  if(World.frameCount% 80 ===0){
  var Banana = createSprite(400,10,10,10);
  Banana.setAnimation("Banana",BananaImg);
  Banana.scale=0.05;
  var rand = randomNumber(120,200);
  Banana.y = rand;
  Banana.velocityX = -5;
  BananaGroup.add(Banana);
    Banana.lifetime(200)
  }
}

function Stone(){
    if(World.frameCount% 80 ===0){
      var Stones = createSprite(100,300,10,10)
      Stones.setAnimation("Stone",StoneImg);
      Stones.scale=0.05;
  var rands = randomNumber(120,200);
  Stones.y = rands;
  Stones.velocityX = -5;
  StoneGroup.add(Stones)
      lifetime(300);
    }
}